@echo off
cd /d "%~dp0"
if not exist .venv (
  echo Creating virtual environment...
  python -m venv .venv
)
call .venv\Scripts\activate.bat
echo Installing requirements (first run only)...
pip install -q -r requirements.txt
echo.
echo Starting FloodShield at http://127.0.0.1:5000  (Ctrl+C to stop)
start "" http://127.0.0.1:5000
python app.py
