"""FloodShield backend (Flask + SQLite). Run:  python app.py  ->  http://localhost:5000"""
import csv
import io
import json
import os
import sqlite3
import time
import urllib.request
from datetime import datetime

from flask import Flask, Response, g, jsonify, request, send_from_directory

import engine as E

BASE = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE, "data", "floodshield.db")
app = Flask(__name__, static_folder=os.path.join(BASE, "static"), static_url_path="/static")
print("Training flood model and building district ...")
ENG = E.Engine()
print("Ready. Model AUC:", ENG.model.info["auc"])

REPORT_KINDS = {"need_help": "Need help / stranded", "medical": "Medical emergency", "water_rising": "Water rising",
                "road_blocked": "Road / bridge blocked", "shelter_full": "Shelter full"}


# ---------------- database ----------------
def db():
    if "db" not in g:
        os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
    return g.db


@app.teardown_appcontext
def close_db(_):
    d = g.pop("db", None)
    if d:
        d.close()


def init_db():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    c = sqlite3.connect(DB_PATH)
    c.executescript("""
    CREATE TABLE IF NOT EXISTS reports(id INTEGER PRIMARY KEY, created TEXT, kind TEXT, cell INTEGER, note TEXT, status TEXT DEFAULT 'open', votes INTEGER DEFAULT 0);
    CREATE TABLE IF NOT EXISTS alerts(id INTEGER PRIMARY KEY, created TEXT, village TEXT, lang TEXT, message TEXT, recipients INTEGER, status TEXT);
    CREATE TABLE IF NOT EXISTS scenarios(id INTEGER PRIMARY KEY, created TEXT, name TEXT, rain REAL, capacity INTEGER, shelters TEXT);
    """)
    if c.execute("SELECT COUNT(*) FROM reports").fetchone()[0] == 0:       # demo data so the page is not empty
        for kind, village, note in [("need_help", 1, "Family of 6 on rooftop, water at the doorstep"),
                                    ("road_blocked", 3, "Culvert overflowing, road impassable for carts"),
                                    ("water_rising", 6, "Water rose ~1 ft in the last hour"),
                                    ("medical", 0, "Elderly person needs dialysis, cannot reach clinic")]:
            v = ENG.d.villages[village]
            c.execute("INSERT INTO reports(created,kind,cell,note) VALUES(?,?,?,?)",
                      (datetime.now().isoformat(timespec="minutes"), kind, v["cell"], note))
    c.commit(); c.close()


init_db()


# ---------------- helpers ----------------
def clean_shelters(v):
    out = []
    for x in (v or [])[:30]:
        try:
            x = int(x)
        except (TypeError, ValueError):
            continue
        if 0 <= x < E.NN and x not in out and not ENG.river[x]:
            out.append(x)
    return out


def num(v, lo, hi, default):
    try:
        return max(lo, min(hi, float(v)))
    except (TypeError, ValueError):
        return default


def need_help_counts():
    rows = db().execute("SELECT cell FROM reports WHERE status='open' AND kind IN ('need_help','medical')").fetchall()
    cnt = {}
    for r in rows:
        n = ENG.d.village_at(r["cell"]); cnt[n] = cnt.get(n, 0) + 1
    return cnt


def row_report(r):
    return {"id": r["id"], "created": r["created"], "kind": r["kind"], "label": REPORT_KINDS.get(r["kind"], r["kind"]),
            "cell": r["cell"], "village": ENG.d.village_at(r["cell"]), "note": r["note"], "status": r["status"], "votes": r["votes"]}


# ---------------- routes ----------------
@app.get("/")
def index():
    return send_from_directory(app.static_folder, "index.html")


@app.get("/api/health")
def health():
    return {"ok": True, "model": ENG.model.info["type"], "time": datetime.now().isoformat(timespec="seconds")}


@app.get("/api/district")
def district():
    return jsonify(ENG.d.to_json())


@app.get("/api/model")
def model():
    return jsonify(ENG.model.info)


@app.post("/api/analyze")
def analyze():
    b = request.get_json(silent=True) or {}
    rain = num(b.get("rain"), 0, 400, 150)
    cap = int(num(b.get("capacity"), 100, 20000, 2500))
    return jsonify(ENG.analyze(rain, clean_shelters(b.get("shelters")), cap, need_help_counts()))


@app.post("/api/optimize")
def optimize():
    b = request.get_json(silent=True) or {}
    rain = num(b.get("rain"), 0, 400, 150)
    k = int(num(b.get("k"), 1, 15, 5))
    cap = int(num(b.get("capacity"), 100, 20000, 2500))
    return jsonify({"shelters": ENG.optimize(rain, k, cap)})


@app.get("/api/forecast")
def forecast():
    kind = request.args.get("scenario", "monsoon")
    source = "Synthetic scenario: " + E.Engine.SCEN.get(kind, "Monsoon spell")
    live = request.args.get("live") == "1"
    hourly = E.Engine.scenario_hourly(kind)
    if live:
        lat, lon = num(request.args.get("lat"), -90, 90, 25.59), num(request.args.get("lon"), -180, 180, 85.14)
        try:      # Open-Meteo is a free, key-less weather API. Needs internet; falls back to the scenario.
            url = ("https://api.open-meteo.com/v1/forecast?latitude=%s&longitude=%s&hourly=precipitation&forecast_days=3" % (lat, lon))
            with urllib.request.urlopen(url, timeout=6) as r:
                data = json.load(r)
            hourly = [float(x or 0) for x in data["hourly"]["precipitation"][:72]]
            source = "Live forecast (Open-Meteo) for %.2f, %.2f" % (lat, lon)
        except Exception as ex:
            source += "  (live forecast unavailable: %s)" % type(ex).__name__
    out = ENG.forecast(hourly)
    out["source"] = source
    return jsonify(out)


@app.get("/api/reports")
def reports_list():
    rows = db().execute("SELECT * FROM reports ORDER BY id DESC LIMIT 100").fetchall()
    return jsonify([row_report(r) for r in rows])


@app.post("/api/reports")
def reports_add():
    b = request.get_json(silent=True) or {}
    kind = b.get("kind")
    try:
        cell = int(b.get("cell"))
    except (TypeError, ValueError):
        return {"error": "cell required"}, 400
    if kind not in REPORT_KINDS or not (0 <= cell < E.NN):
        return {"error": "invalid report"}, 400
    note = str(b.get("note", ""))[:200]
    cur = db().execute("INSERT INTO reports(created,kind,cell,note) VALUES(?,?,?,?)",
                       (datetime.now().isoformat(timespec="minutes"), kind, cell, note))
    db().commit()
    return row_report(db().execute("SELECT * FROM reports WHERE id=?", (cur.lastrowid,)).fetchone()), 201


@app.post("/api/reports/<int:rid>/vote")
def reports_vote(rid):
    db().execute("UPDATE reports SET votes=votes+1 WHERE id=?", (rid,)); db().commit()
    return {"ok": True}


@app.post("/api/reports/<int:rid>/resolve")
def reports_resolve(rid):
    db().execute("UPDATE reports SET status='resolved' WHERE id=?", (rid,)); db().commit()
    return {"ok": True}


@app.post("/api/alerts/preview")
def alerts_preview():
    b = request.get_json(silent=True) or {}
    lang = b.get("lang") if b.get("lang") in E.Engine.TPL else "en"
    msgs = ENG.alert_messages(num(b.get("rain"), 0, 400, 150), clean_shelters(b.get("shelters")),
                              int(num(b.get("capacity"), 100, 20000, 2500)), lang, int(num(b.get("hours"), 1, 72, 6)))
    return jsonify(msgs)


@app.post("/api/alerts/send")
def alerts_send():
    """SIMULATED broadcast: logs messages. Plug an SMS/IVR/WhatsApp gateway (MSG91, Twilio, Gupshup ...) in here."""
    b = request.get_json(silent=True) or {}
    lang = b.get("lang") if b.get("lang") in E.Engine.TPL else "en"
    msgs = ENG.alert_messages(num(b.get("rain"), 0, 400, 150), clean_shelters(b.get("shelters")),
                              int(num(b.get("capacity"), 100, 20000, 2500)), lang, int(num(b.get("hours"), 1, 72, 6)))
    now = datetime.now().isoformat(timespec="seconds")
    for m in msgs:
        db().execute("INSERT INTO alerts(created,village,lang,message,recipients,status) VALUES(?,?,?,?,?,?)",
                     (now, m["village"], lang, m["message"], m["recipients"], "simulated-sent"))
    db().commit()
    return {"sent": len(msgs), "recipients": sum(m["recipients"] for m in msgs)}


@app.get("/api/alerts/log")
def alerts_log():
    rows = db().execute("SELECT * FROM alerts ORDER BY id DESC LIMIT 30").fetchall()
    return jsonify([dict(r) for r in rows])


@app.get("/api/scenarios")
def scenarios_list():
    rows = db().execute("SELECT * FROM scenarios ORDER BY id DESC LIMIT 20").fetchall()
    return jsonify([{**dict(r), "shelters": json.loads(r["shelters"])} for r in rows])


@app.post("/api/scenarios")
def scenarios_save():
    b = request.get_json(silent=True) or {}
    name = str(b.get("name") or "Plan")[:60]
    db().execute("INSERT INTO scenarios(created,name,rain,capacity,shelters) VALUES(?,?,?,?,?)",
                 (datetime.now().isoformat(timespec="minutes"), name, num(b.get("rain"), 0, 400, 150),
                  int(num(b.get("capacity"), 100, 20000, 2500)), json.dumps(clean_shelters(b.get("shelters")))))
    db().commit()
    return {"ok": True}, 201


@app.get("/api/export/supplies.csv")
def export_supplies():
    sh = clean_shelters([x for x in request.args.get("shelters", "").split(",") if x])
    a = ENG.analyze(num(request.args.get("rain"), 0, 400, 150), sh, int(num(request.args.get("capacity"), 100, 20000, 2500)), need_help_counts())
    buf = io.StringIO(); w = csv.writer(buf)
    w.writerow(["village", "people_at_risk", "stranded", "water_litres_3d", "food_packets_3d", "medical_kits", "boats", "tarpaulins"])
    for r in a["supplies"]["rows"]:
        w.writerow([r["name"], r["people"], r["stranded"], r["water_l"], r["food_packets"], r["medical_kits"], r["boats"], r["tarpaulins"]])
    t = a["supplies"]["total"]
    w.writerow(["TOTAL", t["people"], t["stranded"], t["water_l"], t["food_packets"], t["medical_kits"], t["boats"], t["tarpaulins"]])
    return Response(buf.getvalue(), mimetype="text/csv", headers={"Content-Disposition": "attachment; filename=floodshield_supplies.csv"})


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=int(os.environ.get("PORT", 5000)), debug=False)
