# FloodShield – AI + GIS flood preparedness for Bharat
Prototype for the Bharat "Hack For Social Cause" hackathon (AI, GIS & Emerging Technologies).

## Run (Windows)
1. Install Python 3.9+ from python.org (tick "Add Python to PATH").
2. Unzip, open the folder in Command Prompt and run:

       run.bat

   First run installs the packages, then opens http://127.0.0.1:5000

Manual commands:

       python -m venv .venv
       .venv\Scripts\activate
       pip install -r requirements.txt
       python app.py

Mac / Linux: `bash run.sh`.  Change port: `set PORT=8000` (Windows) or `PORT=8000 python app.py`.
Self-test: `python test_api.py`

## What is inside
| Part | File | What it does |
|---|---|---|
| Frontend | static/index.html, style.css, app.js | Map, dashboard, 5 tabs, English/Hindi, guided tour |
| Backend API | app.py | Flask REST API + SQLite (reports, alerts, saved plans) |
| Engine | engine.py | Synthetic GIS district, scikit-learn flood model, Dijkstra routing (SciPy), shelter optimizer, 72 h forecast, supplies, multilingual alerts |
| Tests | test_api.py | Smoke tests for every endpoint |

## Features
1. AI flood-risk prediction for every 250 m cell, driven by a rainfall slider.
2. GIS map: terrain, river, bridges, population, vulnerability, risk-weighted evacuation routes on hover.
3. AI shelter optimizer (max coverage of at-risk, vulnerable people within 30 min) plus manual placement.
4. 72-hour early warning: village lead times, timed action plan, live forecast option (Open-Meteo, needs internet).
5. Multilingual alerts (English / Hindi / Tamil), simulated send + log. Plug an SMS/IVR/WhatsApp gateway into `/api/alerts/send`.
6. Relief-supply estimator per village with CSV export and print view.
7. Community reports (SOS, blocked road ...) that raise a village's priority.
8. Save / load shelter plans.

## API
GET /api/district, GET /api/model, POST /api/analyze, POST /api/optimize, GET /api/forecast?scenario=cyclone
GET|POST /api/reports, POST /api/reports/<id>/vote|resolve, POST /api/alerts/preview|send, GET /api/alerts/log
GET|POST /api/scenarios, GET /api/export/supplies.csv

## Data and honesty
All data (district, villages, population, "historical floods") is synthetic; village names are fictional.
To go real: replace `District` in engine.py with SRTM/CartoDEM elevation, IMD/CHIRPS rainfall, Census/WorldPop population,
OpenStreetMap roads and Sentinel-1 flood extents, then retrain `FloodModel` on observed flood labels.
Not tested in the build sandbox: the live-forecast call (needs internet) and run.bat (written for Windows).
