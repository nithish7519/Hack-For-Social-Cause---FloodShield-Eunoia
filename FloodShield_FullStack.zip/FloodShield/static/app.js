"use strict";
/* FloodShield frontend: talks to the Flask API (see app.py). */
const $ = id => document.getElementById(id);
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const fmt = n => Math.round(n).toLocaleString("en-IN");
const esc = s => String(s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
async function api(path, body) {
  const opt = body === undefined ? {} : { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) };
  const r = await fetch(path, opt);
  if (!r.ok) throw new Error(path + " → " + r.status);
  return r.json();
}

/* ---------------- i18n ---------------- */
const I18N = {
  en: {},
  hi: {
    tagline: "बाढ़ से पहले तैयारी · Plan relief before the flood arrives", nav_center: "कमांड सेंटर", nav_about: "परियोजना और प्रभाव",
    rain_title: "24 घंटे की वर्षा", rain_sub: "तूफ़ान का अनुमान देखने के लिए खिसकाएँ",
    l_risk: "बाढ़ जोखिम", l_elev: "भू-आकृति", l_pop: "आबादी", l_vuln: "संवेदनशील",
    t_overview: "अवलोकन", t_shelters: "आश्रय", t_warning: "पूर्व चेतावनी", t_supplies: "राहत सामग्री", t_community: "समुदाय",
    k_aff: "संभावित प्रभावित लोग", k_cov: "30 मिनट में आश्रय तक पहुँच", k_avg: "औसत निकासी समय", k_cap: "आश्रय क्षमता उपयोग",
    villages_h: "प्राथमिकता वाले गाँव — पहले मदद यहाँ", opt_h: "AI आश्रय योजनाकार", optimize: "✨ AI से इष्टतम स्थान चुनें"
  }
};
let lang = "en";
function applyLang() {
  document.documentElement.lang = lang;
  document.querySelectorAll("[data-i18n]").forEach(el => {
    if (el.dataset.en === undefined) el.dataset.en = el.textContent;
    el.textContent = (I18N[lang] || {})[el.dataset.i18n] || el.dataset.en;
  });
  document.querySelectorAll("#langseg button").forEach(b => b.classList.toggle("on", b.dataset.lang === lang));
  if (S.A) renderPanels();
}

/* ---------------- state ---------------- */
const S = { D: null, A: null, rain: 150, layer: "risk", shelters: [], capacity: 2500, tab: "overview", hover: -1, route: null,
  reports: [], reportCell: -1, focus: -1, dirty: true, seq: 0, F: null };
const KINDS = { need_help: ["🆘", "Need help / stranded", "#d33a3a"], medical: ["⚕️", "Medical emergency", "#8e44ad"],
  water_rising: ["🌊", "Water rising", "#0f6fb8"], road_blocked: ["🚧", "Road / bridge blocked", "#b86e00"], shelter_full: ["🏠", "Shelter full", "#555"] };
const THRESH = 30;

/* ---------------- map ---------------- */
const cv = $("map"), ctx = cv.getContext("2d");
const RISKC = [[0, 250, 225, 90], [.35, 245, 160, 50], [.7, 225, 70, 50], [1, 140, 20, 60]];
const ELEV = [[0, 125, 185, 125], [.3, 185, 208, 135], [.65, 228, 216, 165], [1, 205, 195, 180]];
const POPC = [[0, 244, 247, 250], [.3, 200, 215, 245], [.7, 90, 120, 210], [1, 40, 40, 130]];
const VULN = [[0, 244, 247, 250], [.5, 232, 170, 222], [1, 160, 40, 150]];
function ramp(stops, t) {
  t = clamp(t, 0, 1);
  for (let k = 1; k < stops.length; k++) if (t <= stops[k][0]) {
    const a = stops[k - 1], b = stops[k], u = (t - a[0]) / (b[0] - a[0]);
    return [1, 2, 3].map(j => a[j] + (b[j] - a[j]) * u);
  }
  return stops[stops.length - 1].slice(1);
}
function bil(a, x, y, N) {
  x = clamp(x - .5, 0, N - 1.001); y = clamp(y - .5, 0, N - 1.001);
  const x0 = x | 0, y0 = y | 0, fx = x - x0, fy = y - y0, i = y0 * N + x0;
  return a[i] * (1 - fx) * (1 - fy) + a[i + 1] * fx * (1 - fy) + a[i + N] * (1 - fx) * fy + a[i + N + 1] * fx * fy;
}
const SS = 5, base = document.createElement("canvas");
function paintBase() {
  const D = S.D, N = D.N, P = S.A ? S.A.P : null;
  base.width = base.height = N * SS;
  const g = base.getContext("2d"), img = g.createImageData(N * SS, N * SS), d = img.data;
  for (let py = 0; py < N * SS; py++) for (let px = 0; px < N * SS; px++) {
    const cx = (px + .5) / SS, cy = (py + .5) / SS, e = bil(D.elev, cx, cy, N);
    const sh = (bil(D.elev, cx - .8, cy - .8, N) - bil(D.elev, cx + .8, cy + .8, N)) * 5;
    const terr = ramp(ELEV, e / 40).map(v => clamp(v + sh, 0, 255));
    let c;
    if (S.layer === "pop") c = ramp(POPC, bil(D.pop, cx, cy, N) / 230);
    else if (S.layer === "vuln") c = ramp(VULN, bil(D.vuln, cx, cy, N));
    else if (S.layer === "elev" || !P) c = terr;
    else { const p = bil(P, cx, cy, N), a = clamp((p - 0.02) * 2.0, 0, .9), rk = ramp(RISKC, p); c = terr.map((v, j) => v * (1 - a) + rk[j] * a); }
    const r = bil(D.rd, cx, cy, N);
    if (r < 0.8) c = [64, 150, 222]; else if (r < 1.05) { const t = (r - .8) / .25; c = [64, 150, 222].map((v, j) => v * (1 - t) + c[j] * t); }
    const o = (py * N * SS + px) * 4; d[o] = c[0]; d[o + 1] = c[1]; d[o + 2] = c[2]; d[o + 3] = 255;
  }
  g.putImageData(img, 0, 0);
}
function halo(t, x, y, size, col) {
  ctx.font = `bold ${size}px "Segoe UI",system-ui,sans-serif`; ctx.textAlign = "center"; ctx.textBaseline = "middle";
  ctx.lineWidth = size * .3; ctx.strokeStyle = "rgba(255,255,255,.92)"; ctx.lineJoin = "round"; ctx.strokeText(t, x, y); ctx.fillStyle = col; ctx.fillText(t, x, y);
}
function renderMap() {
  const D = S.D; if (!D) return;
  const N = D.N; if (S.dirty) { paintBase(); S.dirty = false; }
  const s = cv.width / N; ctx.imageSmoothingEnabled = true; ctx.imageSmoothingQuality = "high";
  ctx.drawImage(base, 0, 0, cv.width, cv.height);
  ctx.lineCap = "round";
  for (const b of D.bridges) {
    const x = (b.x + .5) * s, y = (b.y + .5) * s;
    ctx.strokeStyle = "#fff"; ctx.lineWidth = s * .8; ctx.beginPath(); ctx.moveTo(x, y - s * 2); ctx.lineTo(x, y + s * 2); ctx.stroke();
    ctx.strokeStyle = "#7a5a32"; ctx.lineWidth = s * .42; ctx.beginPath(); ctx.moveTo(x, y - s * 2); ctx.lineTo(x, y + s * 2); ctx.stroke();
  }
  if (S.route && S.route.length) {
    ctx.lineJoin = "round";
    const path = () => { ctx.beginPath(); S.route.forEach((i, k) => { const px = (i % N + .5) * s, py = (((i / N) | 0) + .5) * s; k ? ctx.lineTo(px, py) : ctx.moveTo(px, py); }); ctx.stroke(); };
    ctx.setLineDash([]); ctx.strokeStyle = "#fff"; ctx.lineWidth = s * .62; path();
    ctx.strokeStyle = "#0b4f9c"; ctx.lineWidth = s * .3; ctx.setLineDash([s * .55, s * .3]); path(); ctx.setLineDash([]);
  }
  D.villages.forEach((v, i) => {
    const x = (v.x + .5) * s, y = (v.y + .5) * s;
    if (i === S.focus) { ctx.strokeStyle = "#d33a3a"; ctx.lineWidth = s * .25; ctx.beginPath(); ctx.arc(x, y, s * 2.2, 0, 7); ctx.stroke(); }
    ctx.fillStyle = "#1b2a38"; ctx.beginPath(); ctx.arc(x, y, s * .28, 0, 7); ctx.fill();
    halo(v.name, x, y - s * .95, s * .82, "#14212e");
  });
  halo("River  नदी", 31.5 * s, (D.bridges[0] ? 0 : 0) + riverLabelY() * s, s * .85, "#0b4f9c");
  // community reports
  for (const r of S.reports) {
    if (r.status !== "open") continue;
    const k = KINDS[r.kind] || KINDS.need_help, x = (r.cell % N + .5) * s, y = (((r.cell / N) | 0) + .5) * s;
    ctx.fillStyle = k[2]; ctx.strokeStyle = "#fff"; ctx.lineWidth = s * .18;
    ctx.beginPath(); ctx.moveTo(x, y - s * .95); ctx.lineTo(x + s * .8, y + s * .6); ctx.lineTo(x - s * .8, y + s * .6); ctx.closePath(); ctx.fill(); ctx.stroke();
    ctx.fillStyle = "#fff"; ctx.font = `bold ${s * .8}px system-ui`; ctx.textAlign = "center"; ctx.textBaseline = "middle"; ctx.fillText("!", x, y + s * .05);
  }
  if (S.reportCell >= 0) {
    const x = (S.reportCell % N + .5) * s, y = (((S.reportCell / N) | 0) + .5) * s;
    ctx.strokeStyle = "#8e44ad"; ctx.lineWidth = s * .25; ctx.beginPath(); ctx.arc(x, y, s * 1.3, 0, 7); ctx.stroke();
  }
  // shelters
  const A = S.A;
  S.shelters.forEach((sh, k) => {
    const x = (sh % N + .5) * s, y = (((sh / N) | 0) + .5) * s, bad = A && A.P[sh] >= 0.5, r = s * 1.25;
    ctx.fillStyle = bad ? "#d33a3a" : "#12805a"; ctx.strokeStyle = "#fff"; ctx.lineWidth = s * .22;
    ctx.beginPath(); ctx.arc(x, y, r, 0, 7); ctx.fill(); ctx.stroke();
    ctx.fillStyle = "#fff"; ctx.font = `bold ${s * 1.05}px system-ui`; ctx.textAlign = "center"; ctx.textBaseline = "middle"; ctx.fillText(bad ? "✕" : "S" + (k + 1), x, y + s * .05);
  });
  if (S.hover >= 0) { ctx.strokeStyle = "#14212e"; ctx.lineWidth = 2; ctx.strokeRect((S.hover % N) * s, ((S.hover / N) | 0) * s, s, s); }
  // compass + scale
  const cx0 = cv.width - s * 2.2, cy0 = s * 3;
  ctx.fillStyle = "rgba(255,255,255,.9)"; ctx.beginPath(); ctx.arc(cx0, cy0, s * 1.7, 0, 7); ctx.fill();
  ctx.fillStyle = "#14212e"; ctx.beginPath(); ctx.moveTo(cx0, cy0 - s * 1.3); ctx.lineTo(cx0 + s * .45, cy0 + s * .4); ctx.lineTo(cx0, cy0 + s * .05); ctx.lineTo(cx0 - s * .45, cy0 + s * .4); ctx.closePath(); ctx.fill();
  ctx.font = `bold ${s * .8}px system-ui`; ctx.textAlign = "center"; ctx.fillText("N", cx0, cy0 + s * 1.05);
  ctx.fillStyle = "rgba(255,255,255,.92)"; ctx.fillRect(s * .5, cv.height - s * 2.1, s * 9.6, s * 1.6);
  ctx.fillStyle = "#14212e"; ctx.fillRect(s, cv.height - s * 1.2, s * 8, s * .22); ctx.fillRect(s, cv.height - s * 1.45, s * .15, s * .7); ctx.fillRect(s * 9 - .1 * s, cv.height - s * 1.45, s * .15, s * .7);
  ctx.font = `bold ${s * .7}px system-ui`; ctx.textAlign = "left"; ctx.fillText("2 km", s, cv.height - s * 1.65);
}
function riverLabelY() { const x = 31; return 24 + 7 * Math.sin(x / 7.5) + 3 * Math.sin(x / 3.1 + 1) - 1.9 + .5; }
function sizeCanvas() {
  const r = cv.getBoundingClientRect(), d = window.devicePixelRatio || 1;
  cv.width = Math.round(r.width * d); cv.height = Math.round(r.height * d); renderMap();
}
function legend() {
  const L = {
    risk: [["#fae15a", "Some flood risk"], ["#f5a032", "High risk"], ["#d83a30", "Severe"], ["#4096de", "River"], ["#7a5a32", "Bridge"], ["#12805a", "Safe shelter"], ["#d33a3a", "Flooded shelter / SOS"]],
    elev: [["#7db97d", "Low land"], ["#b9d087", "Mid"], ["#e4d8a5", "Higher ground"]],
    pop: [["#c8d7f5", "Few people"], ["#5a78d2", "Many"], ["#282882", "Very dense"]],
    vuln: [["#e8aade", "Medium"], ["#a02896", "High: poor housing, low income"]]
  };
  $("legend").innerHTML = L[S.layer].map(l => `<span style="--c:${l[0]}">${l[1]}</span>`).join("");
}
function cellAt(ev) {
  const r = cv.getBoundingClientRect(), N = S.D.N, x = Math.floor((ev.clientX - r.left) / r.width * N), y = Math.floor((ev.clientY - r.top) / r.height * N);
  return (x < 0 || y < 0 || x >= N || y >= N) ? -1 : y * N + x;
}
function pathFrom(i) { const p = [], nav = S.A.nav; let c = i, guard = 0; while (c >= 0 && guard++ < 5000) { p.push(c); c = nav.pred[c]; } return p; }
cv.addEventListener("mousemove", ev => {
  if (!S.D || !S.A) return;
  const i = cellAt(ev); S.hover = i; const tip = $("tip");
  if (i < 0) { tip.style.display = "none"; S.route = null; renderMap(); return; }
  const D = S.D, A = S.A, nav = A.nav; S.route = null; let rt = "No safe shelter reachable";
  if (!D.river[i] && nav.dist[i] >= 0) { S.route = pathFrom(i); const k = S.shelters.indexOf(nav.src[i]); rt = `<b>${nav.dist[i].toFixed(0)} min</b> walk to shelter S${k + 1}`; }
  const r = cv.getBoundingClientRect();
  tip.innerHTML = D.river[i] ? `<b>${D.bridge[i] ? "Bridge" : "River"}</b>` :
    `<b>${esc(D.villages[D.vidx[i]].name)} area</b><br>Flood chance: <b>${(A.P[i] * 100).toFixed(0)}%</b><br>Elevation ${D.elev[i].toFixed(1)} m · river ${(D.rd[i] * D.cell_m).toFixed(0)} m<br>People ${D.pop[i]} · vulnerable ${(D.vuln[i] * 100).toFixed(0)}%<br>${rt}`;
  tip.style.display = "block"; tip.style.left = Math.min(ev.clientX - r.left + 14, r.width - 190) + "px"; tip.style.top = Math.min(ev.clientY - r.top + 14, r.height - 120) + "px";
  renderMap();
});
cv.addEventListener("mouseleave", () => { S.hover = -1; S.route = null; $("tip").style.display = "none"; renderMap(); });
cv.addEventListener("click", ev => {
  const i = cellAt(ev); if (i < 0 || !S.D || S.D.river[i]) return;
  if (S.tab === "community") { S.reportCell = i; $("rloc").textContent = `${S.D.villages[S.D.vidx[i]].name} area · cell ${i % S.D.N},${(i / S.D.N) | 0}`; renderMap(); return; }
  const N = S.D.N, near = S.shelters.findIndex(s => Math.hypot(s % N - i % N, ((s / N) | 0) - ((i / N) | 0)) < 1.6);
  if (near >= 0) S.shelters.splice(near, 1); else S.shelters.push(i);
  analyze();
});

/* ---------------- analysis ---------------- */
let timer = null;
function analyze(delay = 0) {
  clearTimeout(timer);
  timer = setTimeout(async () => {
    const my = ++S.seq;
    try {
      const A = await api("/api/analyze", { rain: S.rain, shelters: S.shelters, capacity: S.capacity });
      if (my !== S.seq) return;
      S.A = A; S.dirty = true; renderAll();
    } catch (e) { console.error(e); }
  }, delay);
}
function naiveShelters() {
  const D = S.D, N = D.N, order = [...Array(N * N).keys()].filter(i => !D.river[i]).sort((a, b) => D.pop[b] - D.pop[a]), out = [];
  for (const i of order) { if (out.every(o => Math.hypot(o % N - i % N, ((o / N) | 0) - ((i / N) | 0)) > 9)) out.push(i); if (out.length === 4) break; }
  return out;
}

/* ---------------- panels ---------------- */
function renderAll() { renderMap(); renderPanels(); }
function renderPanels() {
  const A = S.A; if (!A) return; const K = A.kpi, hi = lang === "hi";
  $("rainv").textContent = S.rain;
  $("k_aff").textContent = fmt(K.affected); $("k_affp").textContent = K.affected_pct + "% of " + fmt(K.total_pop);
  const kc = $("k_cov"); kc.textContent = K.coverage_pct.toFixed(0) + "%"; kc.style.color = K.coverage_pct >= 80 ? "var(--ok)" : K.coverage_pct >= 50 ? "var(--warn)" : "var(--bad)";
  $("k_covd").textContent = fmt(K.beyond_reach) + (hi ? " लोग पहुँच से बाहर" : " people beyond reach");
  $("k_avg").textContent = K.avg_min.toFixed(0);
  $("k_cap").textContent = K.capacity_total ? Math.round(100 * K.capacity_used / K.capacity_total) + "%" : "–";
  $("k_capd").textContent = fmt(K.capacity_used) + " / " + fmt(K.capacity_total) + " beds";
  const stranded = K.beyond_reach;
  $("headline").innerHTML = hi
    ? `<b>${S.rain} मिमी</b> वर्षा में लगभग <b>${fmt(K.affected)} लोग</b> (${K.affected_pct.toFixed(0)}%) बाढ़ से प्रभावित हो सकते हैं। उनमें से केवल <b>${K.coverage_pct.toFixed(0)}%</b> लोग 30 मिनट में सुरक्षित आश्रय तक पहुँच सकते हैं${stranded > 1 ? ` — <b>${fmt(stranded)} लोग फँसे रह जाएँगे</b>` : ""}।`
    : `At <b>${S.rain} mm</b> of rain, about <b>${fmt(K.affected)} people</b> (${K.affected_pct.toFixed(0)}% of the district) may be flooded. Only <b style="color:${K.coverage_pct >= 80 ? "var(--ok)" : "var(--bad)"}">${K.coverage_pct.toFixed(0)}%</b> can walk to a safe shelter in ${THRESH} minutes${stranded > 1 ? ` — <b>${fmt(stranded)} people are left stranded</b>` : ""}.`;
  const al = [], comp = A.shelters.filter(s => s.flooded).length, over = A.shelters.filter(s => s.over).length;
  if (comp) al.push(`<div class="alert">${comp} shelter${comp > 1 ? "s sit" : " sits"} in the predicted flood zone and would be unusable (red ✕).</div>`);
  if (over) al.push(`<div class="alert">${over} shelter${over > 1 ? "s are" : " is"} over capacity: add shelters or raise capacity.</div>`);
  if (K.unserved > 1) al.push(`<div class="alert">${fmt(K.unserved)} at-risk people have no safe path to any shelter.</div>`);
  if (!al.length && K.coverage_pct >= 80) al.push(`<div class="alert good">Good coverage: ${K.coverage_pct.toFixed(0)}% of affected people can reach a safe shelter within ${THRESH} min.</div>`);
  $("alerts").innerHTML = al.join("");
  $("villages").innerHTML = A.villages.map(v => {
    const w = v.walk_min, cls = w === null ? "r" : w > THRESH ? "r" : w > 20 ? "y" : "g";
    return `<tr data-v="${v.rank}" style="cursor:pointer"><td>${v.rank}</td><td><b>${esc(v.name)}</b></td><td>${fmt(v.at_risk)}<br><small class="mut">${v.risk_pct}% of village</small></td><td>${Math.round(v.vuln * 100)}%</td><td><span class="pill ${cls}">${w === null ? "no route" : w.toFixed(0) + " min"}</span></td><td>${v.help_reports ? `<span class="pill r">${v.help_reports}</span>` : "–"}</td></tr>`;
  }).join("");
  document.querySelectorAll("#villages tr").forEach(tr => tr.onclick = () => { const v = A.villages[+tr.dataset.v - 1]; S.focus = S.D.villages.findIndex(x => x.name === v.name); renderMap(); });
  // shelters pane
  $("shelterlist").innerHTML = A.shelters.length ? A.shelters.map((s, k) => {
    const pct = s.flooded ? 0 : Math.min(100, 100 * s.load / S.capacity);
    return `<div class="shelter"><span class="dot ${s.flooded ? "bad" : ""}">${s.flooded ? "✕" : "S" + (k + 1)}</span><span class="nm">${esc(s.village)} area ${s.flooded ? '<span class="pill r">flooded</span>' : ""}</span><div class="bar"><i style="width:${pct}%;background:${s.flooded ? "var(--bad)" : s.over ? "var(--warn)" : "var(--ac)"}"></i></div><span style="min-width:56px;text-align:right">${s.flooded ? "–" : fmt(s.load)}</span><button class="btn sm" data-rm="${k}">✕</button></div>`;
  }).join("") : '<p class="mut">No shelters yet. Click the map or press Optimize.</p>';
  document.querySelectorAll("[data-rm]").forEach(b => b.onclick = () => { S.shelters.splice(+b.dataset.rm, 1); analyze(); });
  // supplies
  const T = A.supplies.total;
  $("suptot").innerHTML = [["Water", (T.water_l / 1000).toFixed(1) + " kL", "💧"], ["Food packets", fmt(T.food_packets), "🍚"], ["Medical kits", fmt(T.medical_kits), "⚕️"], ["Boats", fmt(T.boats), "🚤"], ["Tarpaulins", fmt(T.tarpaulins), "⛺"]]
    .map(x => `<div class="kpi" style="--c:#0f6fb8"><span class="ki">${x[2]}</span><small>${x[0]}</small><b style="font-size:20px">${x[1]}</b></div>`).join("");
  $("suptable").innerHTML = A.supplies.rows.filter(r => r.people > 0).sort((a, b) => b.people - a.people).map(r => `<tr><td><b>${esc(r.name)}</b></td><td>${fmt(r.people)}</td><td>${fmt(r.water_l)}</td><td>${fmt(r.food_packets)}</td><td>${r.medical_kits}</td><td>${r.boats}</td><td>${fmt(r.tarpaulins)}</td></tr>`).join("");
  $("supnote").textContent = "Assumptions: " + A.supplies.assumptions;
  $("csv").href = `/api/export/supplies.csv?rain=${S.rain}&capacity=${S.capacity}&shelters=${S.shelters.join(",")}`;
}
function renderModel(m) {
  $("mtag").textContent = "AUC " + m.auc.toFixed(2);
  const mx = Math.max(...m.features.map(f => Math.abs(f.weight)));
  $("modelbox").innerHTML = `<p class="mut">${esc(m.type)} trained on ${fmt(m.events)} simulated flood events. Held-out accuracy <b>${(m.accuracy * 100).toFixed(1)}%</b>, ROC-AUC <b>${m.auc.toFixed(3)}</b>. What drives flooding (red raises risk, green lowers it):</p>` +
    m.features.map(f => `<div class="shelter"><span class="nm" style="min-width:150px;color:var(--mu);font-size:12px">${esc(f.name)}</span><div class="bar"><i style="width:${100 * Math.abs(f.weight) / mx}%;background:${f.weight > 0 ? "var(--bad)" : "var(--ok)"}"></i></div><span style="min-width:48px;text-align:right;font-size:12px">${f.weight > 0 ? "+" : ""}${f.weight.toFixed(2)}</span></div>`).join("") +
    '<p class="mut small">Trained on synthetic data. With real DEM, rainfall and flood-extent data the same pipeline applies.</p>';
}

/* ---------------- controls ---------------- */
function setRain(v, delay) { S.rain = v; $("rain").value = v; $("rainv").textContent = v; document.querySelectorAll("#presets button").forEach(b => b.classList.toggle("on", +b.dataset.r === v)); analyze(delay); }
function setLayer(l) { S.layer = l; S.dirty = true; document.querySelectorAll("#layers button").forEach(b => b.classList.toggle("on", b.dataset.l === l)); legend(); renderMap(); }
function setTab(t) {
  S.tab = t; document.querySelectorAll("#tabs button").forEach(b => b.classList.toggle("on", b.dataset.tab === t));
  document.querySelectorAll(".pane").forEach(p => p.classList.toggle("on", p.id === "pane-" + t));
  $("hint").innerHTML = t === "community" ? "📍 <b>Click the map</b> to choose where the report is." : "💡 <b>Hover</b> to see flood chance and the walking route to the nearest safe shelter. <b>Click</b> to add a shelter; click a shelter to remove it.";
  if (t === "warning" && !S.F) runForecast();
  if (t === "community") loadReports();
  if (t === "shelters") loadPlans();
  renderMap();
}
$("rain").oninput = e => setRain(+e.target.value, 140);
document.querySelectorAll("#presets button").forEach(b => b.onclick = () => setRain(+b.dataset.r));
document.querySelectorAll("#layers button").forEach(b => b.onclick = () => setLayer(b.dataset.l));
document.querySelectorAll("#tabs button").forEach(b => b.onclick = () => setTab(b.dataset.tab));
document.querySelectorAll("#langseg button").forEach(b => b.onclick = () => { lang = b.dataset.lang; applyLang(); });
$("k").oninput = e => $("kv").textContent = e.target.value;
$("cap").oninput = e => { S.capacity = +e.target.value; $("capv").textContent = fmt(S.capacity); analyze(140); };
$("opt").onclick = async () => {
  const before = S.A ? S.A.kpi.coverage_pct : 0;
  $("opt").disabled = true; $("opt").textContent = "Optimizing…";
  try {
    const r = await api("/api/optimize", { rain: S.rain, k: +$("k").value, capacity: S.capacity });
    S.shelters = r.shelters; await new Promise(res => { analyze(); setTimeout(res, 400); });
    const after = S.A.kpi.coverage_pct;
    $("optnote").innerHTML = `<div class="big"><span>Coverage within ${THRESH} min</span><b>${before.toFixed(0)}% → ${after.toFixed(0)}%</b><span>with ${S.shelters.length} flood-safe shelters</span></div>`;
  } catch (e) { $("optnote").textContent = "Optimizer failed: " + e.message; }
  $("opt").disabled = false; $("opt").textContent = "✨ Optimize with AI"; applyLang();
};
$("reset").onclick = () => { S.shelters = naiveShelters(); $("optnote").innerHTML = ""; analyze(); };
$("printplan").onclick = () => window.print();

/* plans */
async function loadPlans() {
  const ps = await api("/api/scenarios");
  $("plans").innerHTML = ps.length ? ps.map(p => `<div class="plan"><span><b>${esc(p.name)}</b> <small class="mut">${p.rain} mm · ${p.shelters.length} shelters</small></span><button class="btn sm" data-plan='${p.id}'>Load</button></div>`).join("") : '<p class="mut small">No saved plans yet.</p>';
  document.querySelectorAll("[data-plan]").forEach(b => b.onclick = () => { const p = ps.find(x => x.id == b.dataset.plan); S.shelters = p.shelters; S.capacity = p.capacity; $("cap").value = p.capacity; $("capv").textContent = fmt(p.capacity); setRain(Math.round(p.rain)); });
}
$("saveplan").onclick = async () => { await api("/api/scenarios", { name: $("planname").value || "Plan", rain: S.rain, capacity: S.capacity, shelters: S.shelters }); $("planname").value = ""; loadPlans(); };

/* forecast */
$("fscen").onchange = () => $("livebox").classList.toggle("hidden", $("fscen").value !== "live");
$("frun").onclick = runForecast;
async function runForecast() {
  const sc = $("fscen").value, live = sc === "live";
  $("frun").disabled = true;
  try {
    const F = await api(`/api/forecast?scenario=${live ? "monsoon" : sc}${live ? `&live=1&lat=${$("lat").value}&lon=${$("lon").value}` : ""}`);
    S.F = F; $("fsrc").textContent = F.source; drawChart(F);
    $("actions").innerHTML = F.actions.length ? F.actions.map(a => `<li class="${a.overdue ? "od" : ""}"><b>${a.hour === 0 ? "Now" : "T+" + a.hour + " h"}</b> · ${esc(a.text)}${a.overdue ? ' <span class="pill r">start immediately</span>' : ""}</li>`).join("") : "<li>No village crosses the danger level in the next 72 hours.</li>";
    $("ftable").innerHTML = F.villages.map(v => `<tr><td><b>${esc(v.name)}</b></td><td>${v.danger_hour === null ? '<span class="pill g">safe</span>' : `<span class="pill ${v.danger_hour < 24 ? "r" : "y"}">T+${v.danger_hour} h</span>`}</td><td>${v.peak_pct}% of residents</td></tr>`).join("");
  } catch (e) { $("fsrc").textContent = "Forecast failed: " + e.message; }
  $("frun").disabled = false;
}
function drawChart(F) {
  const c = $("fchart"), d = window.devicePixelRatio || 1, W = c.clientWidth, H = c.clientHeight; c.width = W * d; c.height = H * d;
  const g = c.getContext("2d"); g.scale(d, d); g.clearRect(0, 0, W, H);
  const L = 38, R = 48, T = 14, B = 26, w = W - L - R, h = H - T - B, n = 72;
  const mxR = Math.max(5, ...F.hourly) * 1.15, mxA = Math.max(10, F.peak_affected) * 1.15;
  g.font = "11px system-ui"; g.fillStyle = "#5d6e80"; g.strokeStyle = "#e1e9f0"; g.lineWidth = 1;
  for (let i = 0; i <= 4; i++) { const y = T + h * i / 4; g.beginPath(); g.moveTo(L, y); g.lineTo(L + w, y); g.stroke(); g.textAlign = "right"; g.fillText((mxR * (1 - i / 4)).toFixed(0), L - 5, y + 4); g.textAlign = "left"; g.fillText(fmt(mxA * (1 - i / 4)), L + w + 5, y + 4); }
  const bw = w / n; g.fillStyle = "#4096de";
  F.hourly.forEach((v, i) => { const bh = v / mxR * h; g.fillRect(L + i * bw + 1, T + h - bh, Math.max(1, bw - 2), bh); });
  g.strokeStyle = "#d33a3a"; g.lineWidth = 2.5; g.beginPath();
  F.affected.forEach((v, i) => { const x = L + (i + .5) * bw, y = T + h - v / mxA * h; i ? g.lineTo(x, y) : g.moveTo(x, y); }); g.stroke();
  g.fillStyle = "#5d6e80"; g.textAlign = "center"; for (let t = 0; t <= 72; t += 12) g.fillText(t + "h", L + t * bw, H - 8);
  if (F.first_danger_hour !== null) {
    const x = L + (F.first_danger_hour + .5) * bw; g.setLineDash([5, 4]); g.strokeStyle = "#b86e00"; g.lineWidth = 1.5; g.beginPath(); g.moveTo(x, T); g.lineTo(x, T + h); g.stroke(); g.setLineDash([]);
    g.fillStyle = "#b86e00"; g.textAlign = x > W - 100 ? "right" : "left"; g.fillText("First danger T+" + F.first_danger_hour + "h", x + (x > W - 100 ? -4 : 4), T + 11);
  }
}
/* alerts */
async function alertBody() { return { rain: S.rain, shelters: S.shelters, capacity: S.capacity, lang: $("alang").value, hours: S.F && S.F.first_danger_hour ? Math.max(3, Math.min(24, S.F.first_danger_hour)) : 6 }; }
$("aprev").onclick = async () => {
  const m = await api("/api/alerts/preview", await alertBody());
  $("amsgs").innerHTML = m.length ? m.map(x => `<div class="msg"><small>${esc(x.village)} · ~${fmt(x.recipients)} residents</small>${esc(x.message)}</div>`).join("") : '<p class="mut">No village is at enough risk for an alert at this rainfall.</p>';
};
$("asend").onclick = async () => {
  const r = await api("/api/alerts/send", await alertBody());
  $("amsgs").innerHTML = `<div class="alert good">✅ ${r.sent} alerts logged (simulated), reaching about ${fmt(r.recipients)} residents. Connect an SMS/IVR gateway to send for real.</div>` + $("amsgs").innerHTML;
};

/* reports */
$("rkind").innerHTML = Object.entries(KINDS).map(([k, v]) => `<option value="${k}">${v[0]} ${v[1]}</option>`).join("");
async function loadReports() {
  S.reports = await api("/api/reports");
  $("reports").innerHTML = S.reports.map(r => { const k = KINDS[r.kind] || KINDS.need_help;
    return `<div class="rep ${r.status !== "open" ? "done" : ""}"><span class="ri">${k[0]}</span><div class="rb"><b>${esc(r.label)}</b> · ${esc(r.village)} <span class="pill ${r.status === "open" ? "y" : "g"}">${r.status}</span><br>${esc(r.note || "")}<br><small>${esc(r.created)} · 👍 ${r.votes} verified</small></div>${r.status === "open" ? `<div><button class="btn sm" data-vote="${r.id}">👍 Verify</button> <button class="btn sm" data-res="${r.id}">✔ Resolve</button></div>` : ""}</div>`; }).join("");
  document.querySelectorAll("[data-vote]").forEach(b => b.onclick = async () => { await api(`/api/reports/${b.dataset.vote}/vote`, {}); loadReports(); });
  document.querySelectorAll("[data-res]").forEach(b => b.onclick = async () => { await api(`/api/reports/${b.dataset.res}/resolve`, {}); await loadReports(); analyze(); });
  renderMap();
}
$("rsubmit").onclick = async () => {
  if (S.reportCell < 0) { $("rloc").textContent = "⚠ Click the map first"; return; }
  await api("/api/reports", { kind: $("rkind").value, cell: S.reportCell, note: $("rnote").value });
  $("rnote").value = ""; S.reportCell = -1; $("rloc").textContent = "Click the map to set location"; await loadReports(); analyze();
};

/* ---------------- guided tour ---------------- */
const STEPS = [
  { t: "1 · The district", d: "A river district with named villages along the banks. Green = low land, cream = higher ground. Water collects in the low land near the river.", rain: 60, layer: "elev", tab: "overview" },
  { t: "2 · Who lives where", d: "Darker blue = more people. Most villages sit right beside the river, exactly where floods strike first.", rain: 60, layer: "pop", tab: "overview" },
  { t: "3 · AI predicts the flood", d: "The model learned how rainfall, height, river distance and drainage combine. At heavy rain (150 mm), yellow → red shows rising flood chance.", rain: 150, layer: "risk", tab: "overview" },
  { t: "4 · Today's shelters fail", d: "Shelters built near people often sit on the floodplain. In extreme rain (280 mm) they flood (red ✕) and most affected people cannot reach safety.", rain: 280, layer: "risk", reset: true, tab: "overview" },
  { t: "5 · AI places shelters smartly", d: "The optimizer picks flood-safe sites that reach the most at-risk, vulnerable people within a 30-minute walk. Compare the coverage numbers.", rain: 280, layer: "risk", opt: true, tab: "shelters" },
  { t: "6 · Warn people early", d: "A 72-hour forecast gives each village a warning lead time and a timed action plan. Alerts can go out in English, Hindi and Tamil.", rain: 280, layer: "risk", tab: "warning" },
  { t: "7 · Send the right relief", d: "Supplies are estimated per village and can be downloaded as CSV. Community reports (SOS, blocked roads) raise a village's priority. Now try it yourself!", rain: 280, layer: "risk", tab: "supplies" }
];
let step = -1;
function renderTour() {
  const el = $("tour");
  if (step < 0) { el.innerHTML = '<div class="row" style="justify-content:space-between"><div><h3>New here? Take the 1-minute tour</h3><p style="margin:0">See how FloodShield turns rainfall data into a plan that can save lives.</p></div><button class="btn pri" id="st_go">▶ Start guided tour</button></div>'; $("st_go").onclick = () => goStep(0); return; }
  const s = STEPS[step];
  el.innerHTML = `<h3>${s.t}</h3><p>${s.d}</p><div class="row"><button class="btn" id="st_b" ${step === 0 ? "disabled" : ""}>← Back</button><button class="btn pri" id="st_n">${step === STEPS.length - 1 ? "Finish ✓" : "Next →"}</button><span class="mut small">Step ${step + 1} of ${STEPS.length}</span></div>`;
  $("st_b").onclick = () => goStep(step - 1); $("st_n").onclick = () => step === STEPS.length - 1 ? (step = -1, renderTour()) : goStep(step + 1);
}
async function goStep(k) {
  step = k; const s = STEPS[k]; setLayer(s.layer); setTab(s.tab);
  if (s.reset || k < 4) S.shelters = naiveShelters();
  S.rain = s.rain; $("rain").value = s.rain; document.querySelectorAll("#presets button").forEach(b => b.classList.toggle("on", +b.dataset.r === s.rain));
  analyze(); renderTour(); if (s.opt) { await new Promise(r => setTimeout(r, 300)); $("opt").click(); }
}

/* ---------------- routing between pages ---------------- */
function route() {
  const about = location.hash === "#about";
  $("page-center").classList.toggle("hidden", about); $("page-about").classList.toggle("hidden", !about);
  $("nav-center").classList.toggle("on", !about); $("nav-about").classList.toggle("on", about);
  if (!about && S.D) setTimeout(sizeCanvas, 0);
}
window.addEventListener("hashchange", route);
window.addEventListener("resize", () => { if (S.D) sizeCanvas(); if (S.F && S.tab === "warning") drawChart(S.F); });

/* ---------------- boot ---------------- */
(async function boot() {
  try {
    const [D, M, R] = await Promise.all([api("/api/district"), api("/api/model"), api("/api/reports")]);
    S.D = D; S.reports = R; renderModel(M);
    S.shelters = naiveShelters(); legend(); setTab("overview"); renderTour(); route(); sizeCanvas();
    $("loading").style.display = "none"; analyze();
  } catch (e) { $("loading").textContent = "Could not reach the FloodShield server: " + e.message; }
})();
