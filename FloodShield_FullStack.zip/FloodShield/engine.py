"""FloodShield core engine: synthetic GIS district, ML flood model, routing,
shelter optimizer, early-warning forecast, relief-supply estimates, multilingual alerts.

All data is synthetic. Replace District() with real rasters (DEM, rainfall, census) to go live.
"""
import math
import numpy as np
from scipy.sparse import csr_matrix
from scipy.sparse.csgraph import dijkstra
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, roc_auc_score
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

N = 48                 # grid is N x N cells
NN = N * N
CELL_M = 250           # metres per cell
CELL_MIN = 3.75        # minutes to walk one cell (4 km/h)
THRESH = 30.0          # target: reach a shelter within 30 minutes
BRIDGES = [9, 24, 39]
VILLAGE_NAMES = ["Rampur", "Gangapur", "Nayagaon", "Sundarpur", "Kishanpur",
                 "Bhimpur", "Lakshmipur", "Devgaon", "Chandanpur"]
FEATURES = ["Elevation", "River distance", "Drainage", "Rainfall",
            "Rain x elevation", "Rain x river dist.", "Rain x drainage"]


def river_y(x):
    return N * 0.5 + 7 * np.sin(np.asarray(x) / 7.5) + 3 * np.sin(np.asarray(x) / 3.1 + 1)


def _noise(scale, seed):
    r = np.random.default_rng(seed)
    m = int(np.ceil(N / scale)) + 2
    g = r.random((m, m))
    ys, xs = np.mgrid[0:N, 0:N]
    gx, gy = xs / scale, ys / scale
    x0, y0 = gx.astype(int), gy.astype(int)
    fx, fy = gx - x0, gy - y0
    s = lambda t: t * t * (3 - 2 * t)
    a, b, c, d = g[y0, x0], g[y0, x0 + 1], g[y0 + 1, x0], g[y0 + 1, x0 + 1]
    return a + (b - a) * s(fx) + (c - a) * s(fy) + (a - b - c + d) * s(fx) * s(fy)


class District:
    """Synthetic river district. Replace with real GIS layers for production."""

    def __init__(self, seed=7):
        r = np.random.default_rng(seed)
        ys, xs = np.mgrid[0:N, 0:N]
        xr = np.arange(0, N, 0.5)
        pts = np.stack([xr, river_y(xr)], 1)
        d = np.sqrt((xs[..., None] - pts[:, 0]) ** 2 + (ys[..., None] - pts[:, 1]) ** 2).min(-1)
        n1, n2, n3, n4, n5 = (_noise(8, 11), _noise(5, 23), _noise(10, 31), _noise(7, 47), _noise(7, 53))
        hill = np.maximum(0, 10 - np.hypot(xs - 5, ys - 6) * 0.7) + np.maximum(0, 8 - np.hypot(xs - 43, ys - 41) * 0.6)
        self.rd = d
        self.elev = np.clip(2.2 + 1.05 * d + 5 * n1 + 2 * n2 + hill, 0.5, 60)
        self.drain = np.clip(0.25 + 0.55 * n3, 0, 1)
        self.river = d < 1.1
        self.bridge = np.zeros((N, N), bool)
        for bx in BRIDGES:
            for y in range(N):
                for dx in (-1, 0, 1):
                    if self.river[y, bx + dx]:
                        self.bridge[y, bx + dx] = True
        # villages (kept off the water)
        self.villages = []
        for name in VILLAGE_NAMES:
            while True:
                x = 3 + r.random() * (N - 6)
                y = float(np.clip(river_y(x) + (r.random() - 0.5) * 14, 3, N - 4))
                if np.min(np.hypot(pts[:, 0] - x, pts[:, 1] - y)) > 2.6:
                    break
            self.villages.append({"name": name, "x": float(x), "y": y,
                                  "s": 2.5 + r.random() * 3, "a": 140 + r.random() * 220})
        p = np.zeros((N, N))
        for v in self.villages:
            p += v["a"] * np.exp(-((xs - v["x"]) ** 2 + (ys - v["y"]) ** 2) / (2 * v["s"] ** 2))
        p = p * (0.6 + 0.8 * n4) + 4 * r.random((N, N))
        p[self.river] = 0
        self.pop = np.round(p)
        self.vuln = np.clip(0.75 * np.exp(-d / 6) + 0.5 * n5 - 0.1, 0, 1)
        # nearest-village assignment for every cell (Voronoi)
        vx = np.array([v["x"] for v in self.villages]); vy = np.array([v["y"] for v in self.villages])
        self.vidx = np.argmin((xs[..., None] - vx) ** 2 + (ys[..., None] - vy) ** 2, axis=-1)
        for i, v in enumerate(self.villages):
            v["pop"] = int(self.pop[self.vidx == i].sum())
            v["cell"] = int(round(v["y"])) * N + int(round(v["x"]))
        self.total_pop = int(self.pop.sum())

    def village_at(self, cell):
        return self.villages[int(self.vidx.ravel()[cell])]["name"]

    def to_json(self):
        r2 = lambda a, k=2: np.round(a.ravel(), k).tolist()
        return {
            "N": N, "cell_m": CELL_M, "total_pop": self.total_pop,
            "elev": r2(self.elev, 1), "rd": r2(self.rd, 2), "drain": r2(self.drain, 2),
            "pop": self.pop.ravel().astype(int).tolist(), "vuln": r2(self.vuln, 2),
            "river": self.river.ravel().astype(int).tolist(),
            "bridge": self.bridge.ravel().astype(int).tolist(),
            "vidx": self.vidx.ravel().tolist(),
            "villages": [{"name": v["name"], "x": round(v["x"], 2), "y": round(v["y"], 2), "pop": v["pop"]}
                         for v in self.villages],
            "bridges": [{"x": bx, "y": round(float(river_y(bx)), 2)} for bx in BRIDGES],
        }


def _sig(z):
    return 1 / (1 + np.exp(-z))


def _truth(e, r, dr, rain):
    low = np.clip((14 - e) / 12, 0, 1)
    near = np.exp(-r / 3)
    return _sig(-8.5 + 3 * low + 2.4 * near + 1.8 * (1 - dr) + (rain / 90) * (0.6 + 1.4 * low + 0.8 * near))


def _feats(e, r, dr, rain):
    return np.column_stack([e, r, dr, rain, rain * e / 100, rain * r / 100, rain * dr / 100])


class FloodModel:
    """Logistic regression flood-probability model, trained on simulated historical events."""

    def __init__(self, district, seed=99, n_events=7000):
        rng = np.random.default_rng(seed)
        ok = np.flatnonzero(~district.river.ravel())
        cells = rng.choice(ok, n_events)
        rain = 20 + rng.random(n_events) * 300
        e, r, dr = (district.elev.ravel()[cells], district.rd.ravel()[cells], district.drain.ravel()[cells])
        y = (rng.random(n_events) < _truth(e, r, dr, rain)).astype(int)
        X = _feats(e, r, dr, rain)
        Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=0.2, random_state=1)
        self.scaler = StandardScaler().fit(Xtr)
        self.clf = LogisticRegression(C=50, max_iter=2000).fit(self.scaler.transform(Xtr), ytr)
        pte = self.clf.predict_proba(self.scaler.transform(Xte))[:, 1]
        self.d = district
        self.info = {
            "type": "Logistic regression (scikit-learn)", "events": int(n_events),
            "accuracy": round(float(accuracy_score(yte, pte > 0.5)), 4),
            "auc": round(float(roc_auc_score(yte, pte)), 4),
            "features": [{"name": n, "weight": round(float(w), 3)} for n, w in zip(FEATURES, self.clf.coef_[0])],
        }
        self._e, self._r, self._dr = district.elev.ravel(), district.rd.ravel(), district.drain.ravel()
        self._river = district.river.ravel()
        self._cache = {}

    def predict(self, rain):
        rain = float(np.clip(rain, 0, 400))
        key = round(rain, 1)
        if key in self._cache:
            return self._cache[key]
        X = _feats(self._e, self._r, self._dr, np.full(NN, rain))
        p = self.clf.predict_proba(self.scaler.transform(X))[:, 1]
        p[self._river] = 1.0
        if len(self._cache) > 400:
            self._cache.clear()
        self._cache[key] = p
        return p


class Engine:
    def __init__(self):
        self.d = District()
        self.model = FloodModel(self.d)
        self.pop = self.d.pop.ravel()
        self.vuln = self.d.vuln.ravel()
        self.river = self.d.river.ravel()
        self.bridge = self.d.bridge.ravel()
        self.vidx = self.d.vidx.ravel()
        self._build_neighbours()

    # ---------- graph / routing ----------
    def _build_neighbours(self):
        U, V, W = [], [], []
        for dx, dy, w in [(1, 0, 1), (-1, 0, 1), (0, 1, 1), (0, -1, 1), (1, 1, 1.414), (1, -1, 1.414), (-1, 1, 1.414), (-1, -1, 1.414)]:
            ys, xs = np.mgrid[0:N, 0:N]
            nx, ny = xs + dx, ys + dy
            m = (nx >= 0) & (nx < N) & (ny >= 0) & (ny < N)
            U.append((ys * N + xs)[m]); V.append((ny * N + nx)[m]); W.append(np.full(m.sum(), w))
        self.U, self.V, self.W = np.concatenate(U), np.concatenate(V), np.concatenate(W)

    def graph(self, P):
        passable = (~self.river | self.bridge) & (P < 0.92) | self.bridge
        cost = CELL_MIN * (1 + 3 * np.where(self.river, 0.3, P))
        m = passable[self.V]
        return csr_matrix((self.W[m] * cost[self.V[m]], (self.U[m], self.V[m])), shape=(NN, NN))

    def _nav(self, P, shelters):
        active = [s for s in shelters if P[s] < 0.5]
        if not active:
            return active, np.full(NN, np.inf), np.full(NN, -1), np.full(NN, -1)
        dist, pred, src = dijkstra(self.graph(P), directed=True, indices=active, min_only=True, return_predecessors=True)
        pred = np.where(pred < 0, -1, pred); src = np.where(src < 0, -1, src)
        return active, dist, pred, src

    # ---------- analysis ----------
    def analyze(self, rain, shelters, capacity, need_help=None):
        need_help = need_help or {}
        P = self.model.predict(rain)
        active, dist, pred, src = self._nav(P, shelters)
        e = self.pop * P
        fin = np.isfinite(dist)
        near = dist <= THRESH
        aff = float(e.sum())
        cov = float(e[near].sum())
        w = e[fin & (e > 0.01)]
        avg = float((dist[fin & (e > 0.01)] * w).sum() / w.sum()) if w.size else 0.0
        loads = np.bincount(src[fin & (e > 0.01)], weights=e[fin & (e > 0.01)], minlength=NN) if active else np.zeros(NN)
        unserved = float(e[~fin].sum())
        # village table
        vill = []
        for i, v in enumerate(self.d.villages):
            m = self.vidx == i
            ex = float(e[m].sum())
            vw = float((self.vuln[m] * e[m]).sum() / ex) if ex > 1 else 0.0
            stranded = float(e[m & ~near].sum())
            mm = m & fin & (e > 0.01)
            walk = float((dist[mm] * e[mm]).sum() / e[mm].sum()) if mm.any() else None
            nh = need_help.get(v["name"], 0)
            score = ex * (0.6 + vw) * (1 + 0.25 * nh)
            vill.append({"name": v["name"], "pop": v["pop"], "at_risk": round(ex), "vuln": round(vw, 2),
                         "stranded": round(stranded), "walk_min": None if walk is None else round(walk, 1),
                         "help_reports": nh, "score": round(score, 1),
                         "risk_pct": round(100 * ex / max(v["pop"], 1), 1)})
        vill.sort(key=lambda z: -z["score"])
        for k, v in enumerate(vill):
            v["rank"] = k + 1
        payload = {
            "rain": rain,
            "P": np.round(P, 3).tolist(),
            "kpi": {"affected": round(aff), "affected_pct": round(100 * aff / self.d.total_pop, 1),
                    "covered": round(cov), "coverage_pct": round(100 * cov / aff, 1) if aff else 100.0,
                    "beyond_reach": round(aff - cov), "avg_min": round(avg, 1), "unserved": round(unserved),
                    "capacity_total": len(active) * capacity, "capacity_used": round(float(loads.sum())),
                    "total_pop": self.d.total_pop},
            "shelters": [{"cell": int(s), "flooded": bool(P[s] >= 0.5), "load": 0 if P[s] >= 0.5 else round(float(loads[s])),
                          "over": bool(P[s] < 0.5 and loads[s] > capacity), "village": self.d.village_at(s)} for s in shelters],
            "villages": vill,
            "supplies": self.supplies(vill),
            "nav": {"dist": np.where(fin, np.round(dist, 1), -1).tolist(), "pred": pred.tolist(), "src": src.tolist()},
        }
        return payload

    @staticmethod
    def supplies(vill):
        """Relief-supply estimate for 3 days. Sphere-style planning assumptions (editable in code)."""
        rows = []
        for v in vill:
            ex, st = v["at_risk"], v["stranded"]
            rows.append({"name": v["name"], "people": ex, "stranded": st,
                         "water_l": ex * 3 * 3, "food_packets": ex * 3, "medical_kits": math.ceil(ex / 100),
                         "boats": math.ceil(st / 150), "tarpaulins": math.ceil(ex / 5)})
        tot = {k: sum(r[k] for r in rows) for k in ("people", "stranded", "water_l", "food_packets", "medical_kits", "boats", "tarpaulins")}
        return {"rows": rows, "total": tot,
                "assumptions": "3 days: 3 L water + 1 food packet per person per day, 1 medical kit per 100 people, 1 boat per 150 stranded people, 1 tarpaulin per 5-person family."}

    # ---------- optimizer ----------
    def optimize(self, rain, k, capacity):
        P = self.model.predict(rain)
        g = self.graph(P)
        ys, xs = np.mgrid[1:N - 1:2, 1:N - 1:2]
        cands = (ys * N + xs).ravel()
        cands = cands[(~self.river[cands]) & (P[cands] < 0.25)]
        wgt = self.pop * P * (0.6 + self.vuln)
        D = dijkstra(g, directed=True, indices=cands, limit=THRESH)     # shelter -> homes (symmetric approx.)
        within = (D <= THRESH) & (wgt > 0)[None, :]
        covered = np.zeros(NN, bool)
        picks = []
        for _ in range(k):
            gains = (within & ~covered[None, :]) @ wgt
            gains = np.minimum(gains, capacity * 2.2)
            gains[[c in picks for c in cands]] = -1
            b = int(np.argmax(gains))
            if gains[b] <= 0:
                break
            picks.append(int(cands[b])); covered |= within[b]
        return picks

    # ---------- early warning ----------
    SCEN = {"monsoon": "Monsoon spell", "cyclone": "Cyclone landfall", "cloudburst": "Cloudburst"}

    @staticmethod
    def scenario_hourly(kind):
        t = np.arange(72)
        noise = np.random.default_rng(3).random(72) * 1.2
        if kind == "cyclone":
            h = 1 + 26 * np.exp(-((t - 38) / 7) ** 2) + 6 * np.exp(-((t - 20) / 10) ** 2)
        elif kind == "cloudburst":
            h = 0.5 + 55 * np.exp(-((t - 22) / 2.5) ** 2) + 3 * np.exp(-((t - 40) / 10) ** 2)
        else:
            h = 2 + 3 * np.sin(t / 9) ** 2 + 12 * np.exp(-((t - 30) / 10) ** 2) + 7 * np.exp(-((t - 55) / 6) ** 2)
        return np.round(h + noise, 1)

    def forecast(self, hourly, danger=0.35):
        hourly = np.asarray(hourly, float)[:72]
        hourly = np.concatenate([hourly, np.zeros(72 - len(hourly))])
        cs = np.cumsum(hourly)
        rain24 = cs - np.concatenate([np.zeros(24), cs[:-24]])
        affected, vrisk = [], []
        vpop = np.array([max(v["pop"], 1) for v in self.d.villages], float)
        for r in rain24:
            P = self.model.predict(float(min(r, 400)))
            affected.append(float((self.pop * P).sum()))
            vrisk.append(np.bincount(self.vidx, weights=self.pop * P, minlength=len(vpop)) / vpop)
        vrisk = np.array(vrisk)                      # hours x villages
        out = []
        for i, v in enumerate(self.d.villages):
            hit = np.flatnonzero(vrisk[:, i] >= danger)
            out.append({"name": v["name"], "peak_pct": round(float(vrisk[:, i].max() * 100), 1),
                        "danger_hour": int(hit[0]) if hit.size else None, "pop": v["pop"]})
        out.sort(key=lambda z: (z["danger_hour"] is None, z["danger_hour"] or 0, -z["peak_pct"]))
        hrs = [o["danger_hour"] for o in out if o["danger_hour"] is not None]
        h0 = min(hrs) if hrs else None
        actions = []
        if h0 is not None:
            for off, txt in [(-48, "Pre-position food, water and medical kits at depots"),
                             (-24, "Send multilingual alerts to high-risk villages"),
                             (-12, "Open shelters; evacuate vulnerable families first"),
                             (-6, "Deploy boats and close low-lying roads / bridges"),
                             (0, "Flood risk crosses danger level in the first village")]:
                actions.append({"hour": max(0, h0 + off), "text": txt, "overdue": h0 + off < 0})
        return {"hourly": hourly.tolist(), "rain24": np.round(rain24, 1).tolist(),
                "affected": [round(a) for a in affected], "peak_affected": round(max(affected)),
                "peak_hour": int(np.argmax(affected)), "villages": out, "first_danger_hour": h0,
                "actions": actions, "danger_level_pct": int(danger * 100)}

    # ---------- alerts ----------
    TPL = {
        "en": "FLOOD ALERT: Heavy rain expected near {village}. Please reach {shelter} ({mins} min walk) within {h} hours. Carry documents, medicines and drinking water. Emergency: 112",
        "hi": "बाढ़ चेतावनी: {village} के पास भारी बारिश की आशंका है। कृपया {h} घंटे के भीतर {shelter} ({mins} मिनट पैदल) पहुँचें। दस्तावेज़, दवाइयाँ और पीने का पानी साथ लें। आपातकालीन: 112",
        "ta": "வெள்ள எச்சரிக்கை: {village} அருகே கனமழை எதிர்பார்க்கப்படுகிறது. {h} மணி நேரத்திற்குள் {shelter} ({mins} நிமிட நடை) சென்றடையவும். ஆவணங்கள், மருந்துகள், குடிநீர் எடுத்துச் செல்லவும். அவசர உதவி: 112",
    }

    def alert_messages(self, rain, shelters, capacity, lang="en", hours=6):
        P = self.model.predict(rain)
        active, dist, pred, src = self._nav(P, shelters)
        e = self.pop * P
        names = {s: f"Shelter S{shelters.index(s) + 1} near {self.d.village_at(s)}" for s in active}
        msgs = []
        for i, v in enumerate(self.d.villages):
            m = (self.vidx == i)
            ex = float(e[m].sum())
            if ex < 50 or ex / max(v["pop"], 1) < 0.08:
                continue
            ok = m & np.isfinite(dist) & (self.pop > 0)
            if ok.any():
                c = int(np.flatnonzero(ok)[np.argmin(dist[ok])])
                shelter, mins = names[int(src[c])], max(1, int(round(dist[c])))
            else:
                shelter, mins = "the nearest safe high ground", 0
            msgs.append({"village": v["name"], "lang": lang, "recipients": int(v["pop"]), "at_risk": round(ex),
                         "message": self.TPL[lang].format(village=v["name"], shelter=shelter, mins=mins, h=hours)})
        msgs.sort(key=lambda z: -z["at_risk"])
        return msgs
