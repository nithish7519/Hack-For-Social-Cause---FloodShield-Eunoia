# Sample data and test cases
- `sample_requests.json`: example JSON bodies for `/api/analyze`, `/api/optimize`, `/api/reports`, `/api/alerts/preview`.
- `sample_outputs.json`: real outputs of the prototype for those requests (synthetic district, 150 mm rain).
- Try: start the app, then
  `curl -X POST http://127.0.0.1:5000/api/analyze -H "Content-Type: application/json" -d @samples/sample_requests.json`
  (send the `analyze` object only, or use the web UI). Automated checks: `python test_api.py`.
