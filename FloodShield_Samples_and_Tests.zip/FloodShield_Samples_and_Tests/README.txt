FloodShield - sample data and test cases (Team Eunoia, HSC|TN|02046)
samples/sample_requests.json  example API request bodies
samples/sample_outputs.json   real outputs of the prototype (synthetic district, 150 mm rain)
test_api.py                   14 automated checks; run from the project root: python test_api.py
(test_api.py imports app.py/engine.py, so it must sit next to them in the full repository.)
