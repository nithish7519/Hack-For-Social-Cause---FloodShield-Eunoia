"""Smoke tests: python test_api.py"""
import app as A
c = A.app.test_client()
def ok(cond, msg):
    print(("PASS " if cond else "FAIL ") + msg); assert cond, msg
d = c.get("/api/district").json; ok(d["N"] == 48 and len(d["elev"]) == 2304, "district layers")
m = c.get("/api/model").json; ok(m["auc"] > 0.9, "model AUC %.3f acc %.3f" % (m["auc"], m["accuracy"]))
sh = [d["villages"][i] for i in range(4)]
cells = [int(round(v["y"])) * 48 + int(round(v["x"])) for v in sh]
a = c.post("/api/analyze", json={"rain": 150, "shelters": cells, "capacity": 2500}).json
ok(a["kpi"]["affected"] > 0 and len(a["P"]) == 2304, "analyze kpis %s" % a["kpi"])
lo = c.post("/api/analyze", json={"rain": 40, "shelters": cells}).json["kpi"]["affected"]
ok(lo < a["kpi"]["affected"], "more rain -> more affected (%d < %d)" % (lo, a["kpi"]["affected"]))
o = c.post("/api/optimize", json={"rain": 150, "k": 5, "capacity": 2500}).json["shelters"]
ok(len(o) == 5, "optimizer picked %s" % o)
b = c.post("/api/analyze", json={"rain": 150, "shelters": o}).json["kpi"]
ok(b["coverage_pct"] > a["kpi"]["coverage_pct"], "optimized coverage %.0f%% > naive %.0f%%" % (b["coverage_pct"], a["kpi"]["coverage_pct"]))
f = c.get("/api/forecast?scenario=cyclone").json
ok(f["first_danger_hour"] is not None and len(f["affected"]) == 72, "forecast first danger hour %s, source %s" % (f["first_danger_hour"], f["source"]))
r = c.post("/api/reports", json={"kind": "need_help", "cell": 500, "note": "test"}); ok(r.status_code == 201, "report created")
ok(c.post("/api/reports", json={"kind": "bad", "cell": 5}).status_code == 400, "invalid report rejected")
ok(len(c.get("/api/reports").json) >= 5, "reports listed")
al = c.post("/api/alerts/preview", json={"rain": 150, "shelters": o, "lang": "hi"}).json; ok(len(al) > 0, "alerts hi: " + al[0]["message"][:50])
ok(c.post("/api/alerts/send", json={"rain": 150, "shelters": o, "lang": "ta"}).json["sent"] > 0, "alerts sent (simulated)")
ok(c.post("/api/scenarios", json={"name": "t", "rain": 150, "shelters": o}).status_code == 201, "scenario saved")
csv = c.get("/api/export/supplies.csv?rain=150&shelters=" + ",".join(map(str, o))); ok(b"TOTAL" in csv.data, "csv export")
print("ALL OK")
